import { useEffect, useState } from "react";
import axios from "axios";

export default function App() {
  const [students, setStudents] = useState([]);
  const [form, setForm] = useState({
    name: "",
    age: "",
    course: "",
  });
  const [editId, setEditId] = useState(null);

  const API = "http://127.0.0.1:8000/api/students/";

  const loadData = async () => {
    const res = await axios.get(API);
    setStudents(res.data);
  };

  useEffect(() => {
    loadData();
  }, []);

  const saveStudent = async () => {
    if (editId) {
      await axios.put(API + editId + "/", form);
      setEditId(null);
    } else {
      await axios.post(API, form);
    }

    setForm({ name: "", age: "", course: "" });
    loadData();
  };

  const editStudent = (s) => {
    setForm({
      name: s.name,
      age: s.age,
      course: s.course,
    });
    setEditId(s.id);
  };

  const deleteStudent = async (id) => {
    await axios.delete(API + id + "/");
    loadData();
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Student CRUD</h2>

      <input
        placeholder="Name"
        value={form.name}
        onChange={(e) =>
          setForm({ ...form, name: e.target.value })
        }
      />

      <input
        placeholder="Age"
        value={form.age}
        onChange={(e) =>
          setForm({ ...form, age: e.target.value })
        }
      />

      <input
        placeholder="Course"
        value={form.course}
        onChange={(e) =>
          setForm({ ...form, course: e.target.value })
        }
      />

      <button onClick={saveStudent}>
        {editId ? "Update" : "Add"}
      </button>

      <hr />

      <table border="1" cellPadding="10">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Age</th>
            <th>Course</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>
          {students.map((s) => (
            <tr key={s.id}>
              <td>{s.id}</td>
              <td>{s.name}</td>
              <td>{s.age}</td>
              <td>{s.course}</td>

              <td>
                <button onClick={() => editStudent(s)}>
                  Edit
                </button>

                <button
                  onClick={() => deleteStudent(s.id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}