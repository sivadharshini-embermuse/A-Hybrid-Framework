from django.core.validators import EmailValidator
from django.core.exceptions import ValidationError


def validate_student_email(value):
    """Custom wrapper around Django's EmailValidator.

    Kept as a separate function (instead of using EmailValidator directly
    on the model field) so validation rules can be extended later without
    touching models.py.
    """
    validator = EmailValidator(message="Enter a valid email address.")
    validator(value)
