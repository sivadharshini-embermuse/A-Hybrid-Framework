// Central app metadata — referenced across the frontend so that any
// version bump here naturally ripples through the dependency graph.
export const APP_NAME = "Student CRUD";
export const APP_VERSION = "1.1.0";
