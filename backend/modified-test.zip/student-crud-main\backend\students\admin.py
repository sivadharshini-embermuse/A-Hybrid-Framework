from django.contrib import admin
from .models import Student
from .constants import STUDENT_LIST_DISPLAY_FIELDS

# Register your models here.


@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = STUDENT_LIST_DISPLAY_FIELDS
