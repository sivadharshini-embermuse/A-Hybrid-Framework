import axios from "axios";
import { API_BASE_URL } from "./constants";

export const getStudents = () => axios.get(API_BASE_URL);

export const createStudent = (data) => axios.post(API_BASE_URL, data);

export const updateStudent = (id, data) =>
  axios.put(API_BASE_URL + id + "/", data);

export const deleteStudent = (id) =>
  axios.delete(API_BASE_URL + id + "/");
