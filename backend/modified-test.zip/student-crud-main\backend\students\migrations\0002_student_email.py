from django.db import migrations, models
import students.validators


class Migration(migrations.Migration):

    dependencies = [
        ('students', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='student',
            name='email',
            field=models.CharField(
                blank=True,
                default='',
                max_length=255,
                validators=[students.validators.validate_student_email],
                help_text="Student's contact email address.",
            ),
        ),
    ]
