import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { APP_NAME, APP_VERSION } from "./appInfo";

console.log(`${APP_NAME} v${APP_VERSION}`);

ReactDOM.createRoot(
  document.getElementById("root")
).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);