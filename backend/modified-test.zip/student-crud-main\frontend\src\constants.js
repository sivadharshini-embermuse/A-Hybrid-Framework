import { APP_NAME } from "./appInfo";

export const API_BASE_URL = "http://127.0.0.1:8000/api/students/";

export const FORM_FIELDS = [
  { key: "name", label: "Name" },
  { key: "age", label: "Age" },
  { key: "course", label: "Course" },
  { key: "email", label: "Email" },
];

export const EMPTY_FORM = {
  name: "",
  age: "",
  course: "",
  email: "",
};

export const PAGE_TITLE = APP_NAME;
