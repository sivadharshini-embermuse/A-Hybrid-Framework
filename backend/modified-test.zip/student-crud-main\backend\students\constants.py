STUDENT_LIST_DISPLAY_FIELDS = ("id", "name", "age", "course", "email")

EMAIL_FIELD_HELP_TEXT = "Student's contact email address."
