import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
// Student CRUD frontend — see src/appInfo.js for current APP_VERSION
export default defineConfig({
  plugins: [react()],
})
