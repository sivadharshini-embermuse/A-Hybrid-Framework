const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const isValidEmail = (value) => {
  if (!value) return true; // email optional, matches backend blank=True
  return EMAIL_REGEX.test(value);
};
