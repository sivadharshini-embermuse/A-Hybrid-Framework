from django.db import models
from .validators import validate_student_email
from .constants import EMAIL_FIELD_HELP_TEXT

# Create your models here.

class Student(models.Model):
    name = models.CharField(max_length=100)
    age = models.IntegerField()
    course = models.CharField(max_length=100)
    email = models.CharField(
        max_length=255,
        blank=True,
        default="",
        validators=[validate_student_email],
        help_text=EMAIL_FIELD_HELP_TEXT,
    )

    def __str__(self):
        return self.name