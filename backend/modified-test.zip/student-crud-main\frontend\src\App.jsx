import { useEffect, useState } from "react";
import { getStudents, createStudent, updateStudent, deleteStudent } from "./api";
import { FORM_FIELDS, EMPTY_FORM, PAGE_TITLE } from "./constants";
import { isValidEmail } from "./validators";

export default function App() {
  const [students, setStudents] = useState([]);
  const [form, setForm] = useState(EMPTY_FORM);
  const [editId, setEditId] = useState(null);
  const [emailError, setEmailError] = useState("");

  const loadData = async () => {
    const res = await getStudents();
    setStudents(res.data);
  };

  useEffect(() => {
    loadData();
  }, []);

  const saveStudent = async () => {
    if (!isValidEmail(form.email)) {
      setEmailError("Enter a valid email address.");
      return;
    }
    setEmailError("");

    if (editId) {
      await updateStudent(editId, form);
      setEditId(null);
    } else {
      await createStudent(form);
    }

    setForm(EMPTY_FORM);
    loadData();
  };

  const editStudent = (s) => {
    setForm({
      name: s.name,
      age: s.age,
      course: s.course,
      email: s.email || "",
    });
    setEditId(s.id);
  };

  const removeStudent = async (id) => {
    await deleteStudent(id);
    loadData();
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>{PAGE_TITLE}</h2>

      {FORM_FIELDS.map((field) => (
        <input
          key={field.key}
          placeholder={field.label}
          value={form[field.key]}
          onChange={(e) =>
            setForm({ ...form, [field.key]: e.target.value })
          }
        />
      ))}

      {emailError && (
        <div style={{ color: "red", fontSize: 12 }}>{emailError}</div>
      )}

      <button onClick={saveStudent}>
        {editId ? "Update" : "Add"}
      </button>

      <hr />

      <table border="1" cellPadding="10">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Age</th>
            <th>Course</th>
            <th>Email</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>
          {students.map((s) => (
            <tr key={s.id}>
              <td>{s.id}</td>
              <td>{s.name}</td>
              <td>{s.age}</td>
              <td>{s.course}</td>
              <td>{s.email}</td>

              <td>
                <button onClick={() => editStudent(s)}>
                  Edit
                </button>

                <button onClick={() => removeStudent(s.id)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
