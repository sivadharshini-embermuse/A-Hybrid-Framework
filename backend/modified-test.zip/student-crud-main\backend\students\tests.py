from django.test import TestCase
from .app_info import APP_NAME, APP_VERSION

# Create your tests here.
# Tests for {APP_NAME} v{APP_VERSION} (see app_info.py)
