# Central backend app metadata — referenced across the backend so a
# version bump here naturally ripples through the dependency graph.
APP_NAME = "Student CRUD API"
APP_VERSION = "1.1.0"
